# Jetson Xavier NX Developer Kit Regulatory and Compliance Documents

The P3518_P3668_Online _Regulatory_Compliance_Information.pdf document lists regulations with which the Jetson Xavier NX Developer Kit is compliant. The other files listed below are regulatory documents required for sale of Jetson Xavier NX Developer Kit.

| Country        |  Regulatory Body |   Cert Type      |     Filename                   |
|----------------|------------------|------------------|--------------------------------|
| INT'L          | Various          | Environmental    | P3518_ENV.pdf                  |
| INT'L          | IEC              | Safety           | P3518_CB_Cert.pdf              |
| Japan          | VCCI, MIC        | EMC/Radio        | P3518_Japan_Cert.pdf           |
| EU             | EC               | EMC/Safety/Radio | P3518_EU_Cert.pdf              |
| US, Canada     | FCC, ISED        | EMC/Radio        | P3518_US_CA_Cert.pdf           |
| Korea          | RRA              | EMC/Radio        | P3518_Korea_Cert.pdf           |
| Taiwan         | BSMI, NCC        | EMC/Radio        | P3518_Taiwan_Cert.pdf          |
| Australia      | RCM              | EMC/Radio        | P3518_Australia_Cert.pdf       |
| /New Zealand   |                  |                  |                                |
| US, Canada     | TUV              | Safety           | P3518_TUV_Cert.pdf             |
| Ukraine        | UkrSEPRO         | EMC/Safety       | P3518_Ukraine_Cert.pdf         |
| INT'L          | Bluetooth SIG    | BQB              | P3518_BQB_Cert.pdf             |
| Israel         | MOC              | EMC/Safety/Radio | P3518_Israel_Cert.pdf          |
| Philippines    | NTC              | EMC/Safety/Radio | P3518_Philippines_Cert.pdf     |
| Russia         | EACU             | EMC/Safety       | P3518_Russia_EAC_Cert.pdf      |
| Russia         | EACU             | Enviroment       | P3518_Russia_EAC_RoHS_Cert.pdf |
| Russia         | FAC              | Radio            | P3518_Russia_FAC_Cert.pdf      |
| Serbia         | RATEL            | EMC/Safety/Radio | P3518_Serbia_Cert.pdf          |
| Singapore      | IDA              | Radio            | P3518_Singapore_Cert.pdf       |
| China          | SRRC             | Radio            | P3518_SRRC_Cert.pdf            |
| Vietnam        | VNTA             | Radio            | P3518_Vietnam_Cert.pdf         |
| India          | WPC              | Radio            | P3518_WPC_India_Cert.pdf       |